--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE city_pharma_lims;
--
-- Name: city_pharma_lims; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE city_pharma_lims WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


\unrestrict (null)
\connect city_pharma_lims
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: BatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BatchStatus" AS ENUM (
    'QUARANTINE',
    'RELEASED',
    'REJECTED',
    'CONDITIONAL'
);


--
-- Name: InstrumentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InstrumentStatus" AS ENUM (
    'QUALIFIED',
    'CALIBRATION_DUE',
    'OUT_OF_SERVICE',
    'MAINTENANCE'
);


--
-- Name: LaboratoryType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LaboratoryType" AS ENUM (
    'SAF',
    'PENICILLIN',
    'GENERAL',
    'CEPHALOSPORIN'
);


--
-- Name: Priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Priority" AS ENUM (
    'ROUTINE',
    'URGENT',
    'STAT',
    'STABILITY'
);


--
-- Name: ResultStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ResultStatus" AS ENUM (
    'NOT_TESTED',
    'WITHIN_SPEC',
    'OUT_OF_SPEC',
    'OUT_OF_TREND'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'QA_MANAGER',
    'QC_ANALYST',
    'LAB_TECHNICIAN',
    'AUDITOR',
    'MANAGER',
    'DEPUTY_MANAGER',
    'SHIFT_INCHARGE',
    'TESTING_ANALYST',
    'ANALYST'
);


--
-- Name: SampleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SampleStatus" AS ENUM (
    'RECEIVED',
    'LOGGED',
    'ASSIGNED',
    'TESTING_IN_PROGRESS',
    'REVIEW_PENDING',
    'APPROVED',
    'REJECTED',
    'ARCHIVED',
    'CANCELLED',
    'PENDING_SUPERVISOR_ASSIGNMENT',
    'ASSIGNED_FOR_TESTING'
);


--
-- Name: SampleType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SampleType" AS ENUM (
    'RAW_MATERIAL',
    'IN_PROCESS',
    'FINISHED_PRODUCT',
    'STABILITY',
    'WATER_PURIFIED',
    'ENVIRONMENTAL_SWAB'
);


--
-- Name: SubmissionDestination; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubmissionDestination" AS ENUM (
    'MICROBIOLOGY',
    'CHEMICAL',
    'PHYSICAL'
);


--
-- Name: SubmissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubmissionStatus" AS ENUM (
    'DRAFT',
    'REGISTERED',
    'SUBMITTED',
    'RECEIVED',
    'IN_PROGRESS',
    'COMPLETED',
    'REJECTED',
    'CANCELLED'
);


--
-- Name: TestCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TestCategory" AS ENUM (
    'CHEMICAL',
    'PHYSICAL',
    'MICROBIOLOGICAL',
    'CHROMATOGRAPHY',
    'STABILITY'
);


--
-- Name: TestStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TestStatus" AS ENUM (
    'PENDING',
    'IN_ANALYSIS',
    'COMPLETED',
    'VERIFIED',
    'RETEST_REQUIRED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "previousValues" jsonb,
    "newValues" jsonb,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: audit_trails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_trails (
    id text NOT NULL,
    "entityName" text NOT NULL,
    "entityId" text NOT NULL,
    action text NOT NULL,
    "performedById" text,
    "performedByName" text NOT NULL,
    role text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "reasonForChange" text,
    "diffPayload" text
);


--
-- Name: batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batches (
    id text NOT NULL,
    "batchNumber" text NOT NULL,
    "drugProduct" text NOT NULL,
    "dosageForm" text NOT NULL,
    "batchSize" text NOT NULL,
    "manufacturingDate" timestamp(3) without time zone NOT NULL,
    "expiryDate" timestamp(3) without time zone NOT NULL,
    status public."BatchStatus" DEFAULT 'QUARANTINE'::public."BatchStatus" NOT NULL,
    "releaseDate" timestamp(3) without time zone,
    "releasedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: calibration_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calibration_logs (
    id text NOT NULL,
    "instrumentId" text NOT NULL,
    "calibrationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "calibratedById" text,
    "certificateNumber" text NOT NULL,
    "standardUsed" text,
    passed boolean DEFAULT true NOT NULL,
    "nextDue" timestamp(3) without time zone NOT NULL,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: certificates_of_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificates_of_analysis (
    id text NOT NULL,
    "certificateNumber" text NOT NULL,
    "batchId" text NOT NULL,
    "sampleId" text,
    "issuedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "authorizedById" text NOT NULL,
    status text DEFAULT 'ISSUED'::text NOT NULL,
    remarks text,
    "signatureHash" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: instruments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instruments (
    id text NOT NULL,
    "equipmentCode" text NOT NULL,
    name text NOT NULL,
    model text NOT NULL,
    "serialNumber" text NOT NULL,
    manufacturer text NOT NULL,
    "laboratoryRoom" text NOT NULL,
    status public."InstrumentStatus" DEFAULT 'QUALIFIED'::public."InstrumentStatus" NOT NULL,
    "lastCalibrationDate" timestamp(3) without time zone,
    "nextCalibrationDue" timestamp(3) without time zone NOT NULL,
    "calibrationFrequencyDays" integer DEFAULT 90 NOT NULL,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: laboratories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.laboratories (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: oos_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oos_incidents (
    id text NOT NULL,
    "incidentNumber" text NOT NULL,
    "sampleTestId" text NOT NULL,
    "sampleId" text NOT NULL,
    "reportedById" text NOT NULL,
    "phaseOneStatus" text DEFAULT 'INVESTIGATING'::text NOT NULL,
    "labErrorConfirmed" boolean DEFAULT false NOT NULL,
    "rootCauseCategory" text,
    "phaseTwoRequired" boolean DEFAULT false NOT NULL,
    "capaDescription" text,
    "qaApprovalStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "qaManagerId" text,
    "closedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sample_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_submissions (
    id text NOT NULL,
    "sampleId" text NOT NULL,
    "submittedByName" text,
    "submissionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."SubmissionStatus" DEFAULT 'SUBMITTED'::public."SubmissionStatus" NOT NULL,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "destinationLabEnum" public."SubmissionDestination",
    "destinationLabId" text,
    "destinationLaboratory" text DEFAULT 'General Lab'::text NOT NULL,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "submittedByUserId" text
);


--
-- Name: sample_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_tests (
    id text NOT NULL,
    "sampleId" text NOT NULL,
    "testSpecificationId" text NOT NULL,
    "instrumentId" text,
    "analystId" text,
    status public."TestStatus" DEFAULT 'PENDING'::public."TestStatus" NOT NULL,
    "minLimit" double precision,
    "maxLimit" double precision,
    "targetValue" double precision,
    unit text,
    "numericResult" double precision,
    "textResult" text,
    "resultStatus" public."ResultStatus" DEFAULT 'NOT_TESTED'::public."ResultStatus" NOT NULL,
    "testDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "rawDataReference" text,
    comments text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: samples; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.samples (
    id text NOT NULL,
    "sampleCode" text,
    "batchId" text,
    "materialName" text,
    "sourceSupplier" text,
    "samplingLocation" text,
    "samplingDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "sampleQty" double precision,
    unit text DEFAULT 'units'::text NOT NULL,
    "storageCondition" text DEFAULT 'Controlled Room Temp 20-25°C'::text NOT NULL,
    priority public."Priority" DEFAULT 'ROUTINE'::public."Priority" NOT NULL,
    status public."SampleStatus" DEFAULT 'PENDING_SUPERVISOR_ASSIGNMENT'::public."SampleStatus" NOT NULL,
    "chainOfCustody" text,
    barcode text,
    "accessionedById" text,
    "assignedToId" text,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "accessionNo" text,
    "expDate" timestamp(3) without time zone,
    "lotNumber" text,
    "mfgDate" timestamp(3) without time zone,
    nomenclature text NOT NULL,
    "submittedBy" text,
    "archivedAt" timestamp(3) without time zone,
    "archivedByUserId" text,
    "batchLotNumber" text,
    "cancellationReason" text,
    "expiryDate" timestamp(3) without time zone,
    "isArchived" boolean DEFAULT false NOT NULL,
    "laboratoryId" text,
    "laboratoryType" public."LaboratoryType" DEFAULT 'GENERAL'::public."LaboratoryType",
    "manufacturingDate" timestamp(3) without time zone,
    quantity double precision DEFAULT 1.0 NOT NULL,
    "quantityUnit" text DEFAULT 'units'::text NOT NULL,
    "receivedByUserId" text,
    "recordNumber" text,
    "sampleId" text,
    "sampledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "stageType" text DEFAULT 'FINISHED_PRODUCT'::text NOT NULL,
    "submittedByUserId" text,
    "sampleType" public."SampleType" DEFAULT 'FINISHED_PRODUCT'::public."SampleType",
    "assignedAt" timestamp(3) without time zone,
    "assignedById" text,
    "assignmentNotes" text,
    version integer DEFAULT 1 NOT NULL
);


--
-- Name: test_specifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_specifications (
    id text NOT NULL,
    "testCode" text NOT NULL,
    name text NOT NULL,
    category public."TestCategory" DEFAULT 'CHEMICAL'::public."TestCategory" NOT NULL,
    "pharmacopeiaMethod" text DEFAULT 'USP'::text NOT NULL,
    "defaultMinLimit" double precision,
    "defaultMaxLimit" double precision,
    "defaultTarget" double precision,
    unit text,
    "procedureOverview" text,
    "requiresInstrument" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "fullName" text NOT NULL,
    "employeeId" text NOT NULL,
    department text NOT NULL,
    role public."Role" DEFAULT 'QC_ANALYST'::public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hashedRefreshToken" text,
    username text,
    assigned_lab text,
    must_change_password boolean DEFAULT true NOT NULL
);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "userId", action, "entityType", "entityId", "previousValues", "newValues", "timestamp") FROM stdin;
\.
COPY public.audit_logs (id, "userId", action, "entityType", "entityId", "previousValues", "newValues", "timestamp") FROM '$$PATH$$/5245.dat';

--
-- Data for Name: audit_trails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_trails (id, "entityName", "entityId", action, "performedById", "performedByName", role, "timestamp", "ipAddress", "reasonForChange", "diffPayload") FROM stdin;
\.
COPY public.audit_trails (id, "entityName", "entityId", action, "performedById", "performedByName", role, "timestamp", "ipAddress", "reasonForChange", "diffPayload") FROM '$$PATH$$/5242.dat';

--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batches (id, "batchNumber", "drugProduct", "dosageForm", "batchSize", "manufacturingDate", "expiryDate", status, "releaseDate", "releasedBy", notes, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.batches (id, "batchNumber", "drugProduct", "dosageForm", "batchSize", "manufacturingDate", "expiryDate", status, "releaseDate", "releasedBy", notes, "createdAt", "updatedAt") FROM '$$PATH$$/5234.dat';

--
-- Data for Name: calibration_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calibration_logs (id, "instrumentId", "calibrationDate", "calibratedById", "certificateNumber", "standardUsed", passed, "nextDue", remarks, "createdAt") FROM stdin;
\.
COPY public.calibration_logs (id, "instrumentId", "calibrationDate", "calibratedById", "certificateNumber", "standardUsed", passed, "nextDue", remarks, "createdAt") FROM '$$PATH$$/5239.dat';

--
-- Data for Name: certificates_of_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificates_of_analysis (id, "certificateNumber", "batchId", "sampleId", "issuedDate", "authorizedById", status, remarks, "signatureHash", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.certificates_of_analysis (id, "certificateNumber", "batchId", "sampleId", "issuedDate", "authorizedById", status, remarks, "signatureHash", "createdAt", "updatedAt") FROM '$$PATH$$/5241.dat';

--
-- Data for Name: instruments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instruments (id, "equipmentCode", name, model, "serialNumber", manufacturer, "laboratoryRoom", status, "lastCalibrationDate", "nextCalibrationDue", "calibrationFrequencyDays", remarks, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.instruments (id, "equipmentCode", name, model, "serialNumber", manufacturer, "laboratoryRoom", status, "lastCalibrationDate", "nextCalibrationDue", "calibrationFrequencyDays", remarks, "createdAt", "updatedAt") FROM '$$PATH$$/5238.dat';

--
-- Data for Name: laboratories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.laboratories (id, name, code, "isActive", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.laboratories (id, name, code, "isActive", "createdAt", "updatedAt") FROM '$$PATH$$/5244.dat';

--
-- Data for Name: oos_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oos_incidents (id, "incidentNumber", "sampleTestId", "sampleId", "reportedById", "phaseOneStatus", "labErrorConfirmed", "rootCauseCategory", "phaseTwoRequired", "capaDescription", "qaApprovalStatus", "qaManagerId", "closedAt", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.oos_incidents (id, "incidentNumber", "sampleTestId", "sampleId", "reportedById", "phaseOneStatus", "labErrorConfirmed", "rootCauseCategory", "phaseTwoRequired", "capaDescription", "qaApprovalStatus", "qaManagerId", "closedAt", "createdAt", "updatedAt") FROM '$$PATH$$/5240.dat';

--
-- Data for Name: sample_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sample_submissions (id, "sampleId", "submittedByName", "submissionDate", status, remarks, "createdAt", "updatedAt", "destinationLabEnum", "destinationLabId", "destinationLaboratory", "submittedAt", "submittedByUserId") FROM stdin;
\.
COPY public.sample_submissions (id, "sampleId", "submittedByName", "submissionDate", status, remarks, "createdAt", "updatedAt", "destinationLabEnum", "destinationLabId", "destinationLaboratory", "submittedAt", "submittedByUserId") FROM '$$PATH$$/5243.dat';

--
-- Data for Name: sample_tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sample_tests (id, "sampleId", "testSpecificationId", "instrumentId", "analystId", status, "minLimit", "maxLimit", "targetValue", unit, "numericResult", "textResult", "resultStatus", "testDate", "completedAt", "rawDataReference", comments, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.sample_tests (id, "sampleId", "testSpecificationId", "instrumentId", "analystId", status, "minLimit", "maxLimit", "targetValue", unit, "numericResult", "textResult", "resultStatus", "testDate", "completedAt", "rawDataReference", comments, "createdAt", "updatedAt") FROM '$$PATH$$/5237.dat';

--
-- Data for Name: samples; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.samples (id, "sampleCode", "batchId", "materialName", "sourceSupplier", "samplingLocation", "samplingDate", "sampleQty", unit, "storageCondition", priority, status, "chainOfCustody", barcode, "accessionedById", "assignedToId", remarks, "createdAt", "updatedAt", "accessionNo", "expDate", "lotNumber", "mfgDate", nomenclature, "submittedBy", "archivedAt", "archivedByUserId", "batchLotNumber", "cancellationReason", "expiryDate", "isArchived", "laboratoryId", "laboratoryType", "manufacturingDate", quantity, "quantityUnit", "receivedByUserId", "recordNumber", "sampleId", "sampledAt", "stageType", "submittedByUserId", "sampleType", "assignedAt", "assignedById", "assignmentNotes", version) FROM stdin;
\.
COPY public.samples (id, "sampleCode", "batchId", "materialName", "sourceSupplier", "samplingLocation", "samplingDate", "sampleQty", unit, "storageCondition", priority, status, "chainOfCustody", barcode, "accessionedById", "assignedToId", remarks, "createdAt", "updatedAt", "accessionNo", "expDate", "lotNumber", "mfgDate", nomenclature, "submittedBy", "archivedAt", "archivedByUserId", "batchLotNumber", "cancellationReason", "expiryDate", "isArchived", "laboratoryId", "laboratoryType", "manufacturingDate", quantity, "quantityUnit", "receivedByUserId", "recordNumber", "sampleId", "sampledAt", "stageType", "submittedByUserId", "sampleType", "assignedAt", "assignedById", "assignmentNotes", version) FROM '$$PATH$$/5235.dat';

--
-- Data for Name: test_specifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_specifications (id, "testCode", name, category, "pharmacopeiaMethod", "defaultMinLimit", "defaultMaxLimit", "defaultTarget", unit, "procedureOverview", "requiresInstrument", "isActive", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.test_specifications (id, "testCode", name, category, "pharmacopeiaMethod", "defaultMinLimit", "defaultMaxLimit", "defaultTarget", unit, "procedureOverview", "requiresInstrument", "isActive", "createdAt", "updatedAt") FROM '$$PATH$$/5236.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, "passwordHash", "fullName", "employeeId", department, role, "isActive", "lastLogin", "createdAt", "updatedAt", "hashedRefreshToken", username, assigned_lab, must_change_password) FROM stdin;
\.
COPY public.users (id, email, "passwordHash", "fullName", "employeeId", department, role, "isActive", "lastLogin", "createdAt", "updatedAt", "hashedRefreshToken", username, assigned_lab, must_change_password) FROM '$$PATH$$/5233.dat';

--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_trails audit_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trails
    ADD CONSTRAINT audit_trails_pkey PRIMARY KEY (id);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: calibration_logs calibration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_logs
    ADD CONSTRAINT calibration_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates_of_analysis certificates_of_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates_of_analysis
    ADD CONSTRAINT certificates_of_analysis_pkey PRIMARY KEY (id);


--
-- Name: instruments instruments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instruments
    ADD CONSTRAINT instruments_pkey PRIMARY KEY (id);


--
-- Name: laboratories laboratories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laboratories
    ADD CONSTRAINT laboratories_pkey PRIMARY KEY (id);


--
-- Name: oos_incidents oos_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oos_incidents
    ADD CONSTRAINT oos_incidents_pkey PRIMARY KEY (id);


--
-- Name: sample_submissions sample_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_submissions
    ADD CONSTRAINT sample_submissions_pkey PRIMARY KEY (id);


--
-- Name: sample_tests sample_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_tests
    ADD CONSTRAINT sample_tests_pkey PRIMARY KEY (id);


--
-- Name: samples samples_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT samples_pkey PRIMARY KEY (id);


--
-- Name: test_specifications test_specifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_specifications
    ADD CONSTRAINT test_specifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_timestamp_idx ON public.audit_logs USING btree ("timestamp");


--
-- Name: audit_trails_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_trails_action_idx ON public.audit_trails USING btree (action);


--
-- Name: audit_trails_entityName_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_trails_entityName_entityId_idx" ON public.audit_trails USING btree ("entityName", "entityId");


--
-- Name: audit_trails_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_trails_timestamp_idx ON public.audit_trails USING btree ("timestamp");


--
-- Name: batches_batchNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "batches_batchNumber_idx" ON public.batches USING btree ("batchNumber");


--
-- Name: batches_batchNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "batches_batchNumber_key" ON public.batches USING btree ("batchNumber");


--
-- Name: batches_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batches_status_idx ON public.batches USING btree (status);


--
-- Name: calibration_logs_instrumentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calibration_logs_instrumentId_idx" ON public.calibration_logs USING btree ("instrumentId");


--
-- Name: certificates_of_analysis_batchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "certificates_of_analysis_batchId_key" ON public.certificates_of_analysis USING btree ("batchId");


--
-- Name: certificates_of_analysis_certificateNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "certificates_of_analysis_certificateNumber_idx" ON public.certificates_of_analysis USING btree ("certificateNumber");


--
-- Name: certificates_of_analysis_certificateNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "certificates_of_analysis_certificateNumber_key" ON public.certificates_of_analysis USING btree ("certificateNumber");


--
-- Name: instruments_equipmentCode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "instruments_equipmentCode_idx" ON public.instruments USING btree ("equipmentCode");


--
-- Name: instruments_equipmentCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "instruments_equipmentCode_key" ON public.instruments USING btree ("equipmentCode");


--
-- Name: instruments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX instruments_status_idx ON public.instruments USING btree (status);


--
-- Name: laboratories_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX laboratories_code_key ON public.laboratories USING btree (code);


--
-- Name: laboratories_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX laboratories_name_key ON public.laboratories USING btree (name);


--
-- Name: oos_incidents_incidentNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oos_incidents_incidentNumber_idx" ON public.oos_incidents USING btree ("incidentNumber");


--
-- Name: oos_incidents_incidentNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "oos_incidents_incidentNumber_key" ON public.oos_incidents USING btree ("incidentNumber");


--
-- Name: oos_incidents_qaApprovalStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oos_incidents_qaApprovalStatus_idx" ON public.oos_incidents USING btree ("qaApprovalStatus");


--
-- Name: sample_submissions_destinationLaboratory_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sample_submissions_destinationLaboratory_idx" ON public.sample_submissions USING btree ("destinationLaboratory");


--
-- Name: sample_submissions_sampleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sample_submissions_sampleId_idx" ON public.sample_submissions USING btree ("sampleId");


--
-- Name: sample_submissions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sample_submissions_status_idx ON public.sample_submissions USING btree (status);


--
-- Name: sample_tests_resultStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sample_tests_resultStatus_idx" ON public.sample_tests USING btree ("resultStatus");


--
-- Name: sample_tests_sampleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sample_tests_sampleId_idx" ON public.sample_tests USING btree ("sampleId");


--
-- Name: sample_tests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sample_tests_status_idx ON public.sample_tests USING btree (status);


--
-- Name: samples_accessionNo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_accessionNo_idx" ON public.samples USING btree ("accessionNo");


--
-- Name: samples_assignedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_assignedById_idx" ON public.samples USING btree ("assignedById");


--
-- Name: samples_assignedToId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_assignedToId_idx" ON public.samples USING btree ("assignedToId");


--
-- Name: samples_batchLotNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_batchLotNumber_idx" ON public.samples USING btree ("batchLotNumber");


--
-- Name: samples_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_createdAt_idx" ON public.samples USING btree ("createdAt");


--
-- Name: samples_laboratoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_laboratoryId_idx" ON public.samples USING btree ("laboratoryId");


--
-- Name: samples_recordNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_recordNumber_idx" ON public.samples USING btree ("recordNumber");


--
-- Name: samples_sampleCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "samples_sampleCode_key" ON public.samples USING btree ("sampleCode");


--
-- Name: samples_sampleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_sampleId_idx" ON public.samples USING btree ("sampleId");


--
-- Name: samples_sampleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "samples_sampleId_key" ON public.samples USING btree ("sampleId");


--
-- Name: samples_sampledAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "samples_sampledAt_idx" ON public.samples USING btree ("sampledAt");


--
-- Name: samples_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX samples_status_idx ON public.samples USING btree (status);


--
-- Name: test_specifications_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_specifications_category_idx ON public.test_specifications USING btree (category);


--
-- Name: test_specifications_testCode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "test_specifications_testCode_idx" ON public.test_specifications USING btree ("testCode");


--
-- Name: test_specifications_testCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "test_specifications_testCode_key" ON public.test_specifications USING btree ("testCode");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_employeeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "users_employeeId_key" ON public.users USING btree ("employeeId");


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_trails audit_trails_performedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trails
    ADD CONSTRAINT "audit_trails_performedById_fkey" FOREIGN KEY ("performedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calibration_logs calibration_logs_calibratedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_logs
    ADD CONSTRAINT "calibration_logs_calibratedById_fkey" FOREIGN KEY ("calibratedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calibration_logs calibration_logs_instrumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_logs
    ADD CONSTRAINT "calibration_logs_instrumentId_fkey" FOREIGN KEY ("instrumentId") REFERENCES public.instruments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: certificates_of_analysis certificates_of_analysis_authorizedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates_of_analysis
    ADD CONSTRAINT "certificates_of_analysis_authorizedById_fkey" FOREIGN KEY ("authorizedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: certificates_of_analysis certificates_of_analysis_batchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates_of_analysis
    ADD CONSTRAINT "certificates_of_analysis_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES public.batches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: certificates_of_analysis certificates_of_analysis_sampleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates_of_analysis
    ADD CONSTRAINT "certificates_of_analysis_sampleId_fkey" FOREIGN KEY ("sampleId") REFERENCES public.samples(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: oos_incidents oos_incidents_qaManagerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oos_incidents
    ADD CONSTRAINT "oos_incidents_qaManagerId_fkey" FOREIGN KEY ("qaManagerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: oos_incidents oos_incidents_reportedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oos_incidents
    ADD CONSTRAINT "oos_incidents_reportedById_fkey" FOREIGN KEY ("reportedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: oos_incidents oos_incidents_sampleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oos_incidents
    ADD CONSTRAINT "oos_incidents_sampleId_fkey" FOREIGN KEY ("sampleId") REFERENCES public.samples(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oos_incidents oos_incidents_sampleTestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oos_incidents
    ADD CONSTRAINT "oos_incidents_sampleTestId_fkey" FOREIGN KEY ("sampleTestId") REFERENCES public.sample_tests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sample_submissions sample_submissions_destinationLabId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_submissions
    ADD CONSTRAINT "sample_submissions_destinationLabId_fkey" FOREIGN KEY ("destinationLabId") REFERENCES public.laboratories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sample_submissions sample_submissions_sampleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_submissions
    ADD CONSTRAINT "sample_submissions_sampleId_fkey" FOREIGN KEY ("sampleId") REFERENCES public.samples(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sample_submissions sample_submissions_submittedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_submissions
    ADD CONSTRAINT "sample_submissions_submittedByUserId_fkey" FOREIGN KEY ("submittedByUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sample_tests sample_tests_analystId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_tests
    ADD CONSTRAINT "sample_tests_analystId_fkey" FOREIGN KEY ("analystId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sample_tests sample_tests_instrumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_tests
    ADD CONSTRAINT "sample_tests_instrumentId_fkey" FOREIGN KEY ("instrumentId") REFERENCES public.instruments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sample_tests sample_tests_sampleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_tests
    ADD CONSTRAINT "sample_tests_sampleId_fkey" FOREIGN KEY ("sampleId") REFERENCES public.samples(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sample_tests sample_tests_testSpecificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_tests
    ADD CONSTRAINT "sample_tests_testSpecificationId_fkey" FOREIGN KEY ("testSpecificationId") REFERENCES public.test_specifications(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: samples samples_accessionedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_accessionedById_fkey" FOREIGN KEY ("accessionedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_assignedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_batchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES public.batches(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_laboratoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_laboratoryId_fkey" FOREIGN KEY ("laboratoryId") REFERENCES public.laboratories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_receivedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_receivedByUserId_fkey" FOREIGN KEY ("receivedByUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: samples samples_submittedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT "samples_submittedByUserId_fkey" FOREIGN KEY ("submittedByUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

